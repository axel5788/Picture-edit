# -*- coding: utf-8 -*-
"""
Created on Thu Nov 15 13:43:08 2018

@author: +
"""



def image_negatif(fichier_init, fichier_final,larg_image,haut_image): # un fichier contient ligne par ligne le code de l'image initiale avant - retouche ,  le second sera l'image convertie en négatif
    
    f = open(fichier_init, 'r')

    NumberOfLine = 0
    for line in f:
        NumberOfLine += 1

    f.close()
    f = open(fichier_init, 'r') #on reouvre le fichier pour s'assurer que le curseur reparte du début du fichier

    s = open(fichier_final, 'w') # le fichier final qui contiendra l'image en négatif

    #Parametre de l'image
    s.write("P3"+"\n")
    s.write("# CREATOR: GIMP PNM Filter Version 1.1"+"\n")
    s.write(larg_image + " " + haut_image +"\n")
    s.write("255"+"\n")
    
    for i in range (0,NumberOfLine):
        # dans la boucle on convertit chaque valeur vers le négatif par l'equation x = 255 - x , puis on l'écrit ligne par ligne dans le fichier final définit au préalable par l'utilisateur
        listemots = f.readline()[:-1]
        
        c = int(listemots)
        a = int(255-c)
        s.write(str(a)+"\n")
        
        
    f.close()
    s.close()
    
    
    #pous nous ex use : image_negatif("init.ppm","final.ppm","200","133")